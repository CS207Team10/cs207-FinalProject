from setuptools import setup

setup(name='cs207-FinalProject',
      version='0.1',
      description='chemical kinetics library',
      url='https://github.com/CS207Team10/cs207-FinalProject',
      author='Hidenori Tanaka, Jiachen Song, Xiangru Shu',
      packages=['cs207-FinalProject'],
      zip_safe=False)
